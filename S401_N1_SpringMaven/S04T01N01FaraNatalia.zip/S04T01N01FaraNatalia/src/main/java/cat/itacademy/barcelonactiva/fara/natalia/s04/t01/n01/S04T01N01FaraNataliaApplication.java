package cat.itacademy.barcelonactiva.fara.natalia.s04.t01.n01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T01N01FaraNataliaApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T01N01FaraNataliaApplication.class, args);
	}

}
